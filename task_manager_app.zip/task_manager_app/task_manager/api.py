from datetime import datetime
from flask import Blueprint, request, jsonify, abort
from flask_login import login_required, current_user
from .extensions import db
from .models import Task

api_bp = Blueprint('api', __name__)

def serialize(task):
    return {
        "id": task.id,
        "title": task.title,
        "description": task.description,
        "priority": task.priority,
        "status": task.status,
        "due_date": task.due_date.isoformat() if task.due_date else None,
        "category_id": task.category_id,
        "created_at": task.created_at.isoformat(),
    }

@api_bp.route('/tasks', methods=['GET'])
@login_required
def api_list_tasks():
    q = request.args.get('q', '').strip()
    status = request.args.get('status', '')
    priority = request.args.get('priority', '')
    category_id = request.args.get('category_id', '')

    tasks = Task.query.filter_by(user_id=current_user.id)

    if q:
        like = f"%{q}%"
        tasks = tasks.filter((Task.title.ilike(like)) | (Task.description.ilike(like)))
    if status:
        tasks = tasks.filter(Task.status == status)
    if priority:
        tasks = tasks.filter(Task.priority == priority)
    if category_id:
        tasks = tasks.filter(Task.category_id == int(category_id))

    tasks = tasks.order_by(Task.due_date.is_(None), Task.due_date.asc()).all()
    return jsonify([serialize(t) for t in tasks])

@api_bp.route('/tasks', methods=['POST'])
@login_required
def api_create_task():
    data = request.get_json(force=True) or {}
    title = data.get('title', '').strip()
    if not title:
        return jsonify({"error": "Title is required"}), 400

    due_date = None
    if data.get('due_date'):
        due_date = datetime.fromisoformat(data['due_date']).date()

    task = Task(
        title=title,
        description=data.get('description', ''),
        priority=data.get('priority', 'Medium'),
        status=data.get('status', 'Pending'),
        due_date=due_date,
        user_id=current_user.id,
        category_id=data.get('category_id')
    )
    db.session.add(task)
    db.session.commit()
    return jsonify(serialize(task)), 201

@api_bp.route('/tasks/<int:task_id>', methods=['GET'])
@login_required
def api_get_task(task_id):
    task = Task.query.filter_by(id=task_id, user_id=current_user.id).first_or_404()
    return jsonify(serialize(task))

@api_bp.route('/tasks/<int:task_id>', methods=['PUT'])
@login_required
def api_update_task(task_id):
    task = Task.query.filter_by(id=task_id, user_id=current_user.id).first_or_404()
    data = request.get_json(force=True) or {}

    if 'title' in data:
        title = data.get('title', '').strip()
        if not title:
            return jsonify({"error": "Title is required"}), 400
        task.title = title
    if 'description' in data: task.description = data['description']
    if 'priority' in data: task.priority = data['priority']
    if 'status' in data: task.status = data['status']
    if 'category_id' in data: task.category_id = data['category_id']
    if 'due_date' in data:
        task.due_date = datetime.fromisoformat(data['due_date']).date() if data['due_date'] else None

    db.session.commit()
    return jsonify(serialize(task))

@api_bp.route('/tasks/<int:task_id>', methods=['DELETE'])
@login_required
def api_delete_task(task_id):
    task = Task.query.filter_by(id=task_id, user_id=current_user.id).first_or_404()
    db.session.delete(task)
    db.session.commit()
    return jsonify({"status": "deleted"}), 200
