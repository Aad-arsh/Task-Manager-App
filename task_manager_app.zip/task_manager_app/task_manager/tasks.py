from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from .extensions import db
from .models import Task, Category

tasks_bp = Blueprint('tasks', __name__, url_prefix='/tasks')

@tasks_bp.route('/')
@login_required
def list_tasks():
    q = request.args.get('q', '').strip()
    status = request.args.get('status', '')
    priority = request.args.get('priority', '')
    category_id = request.args.get('category_id', '')

    tasks = Task.query.filter_by(user_id=current_user.id)

    if q:
        like = f"%{q}%"
        tasks = tasks.filter((Task.title.ilike(like)) | (Task.description.ilike(like)))
    if status:
        tasks = tasks.filter(Task.status == status)
    if priority:
        tasks = tasks.filter(Task.priority == priority)
    if category_id:
        tasks = tasks.filter(Task.category_id == int(category_id))

    tasks = tasks.order_by(Task.due_date.is_(None), Task.due_date.asc())

    categories = Category.query.order_by(Category.name.asc()).all()
    return render_template('tasks.html', tasks=tasks.all(), categories=categories, filters={
        'q': q, 'status': status, 'priority': priority, 'category_id': category_id
    })

@tasks_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create_task():
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        priority = request.form.get('priority', 'Medium')
        status = request.form.get('status', 'Pending')
        due_date_str = request.form.get('due_date', '').strip()
        category_id = request.form.get('category_id') or None

        if not title:
            flash('Title is required', 'danger')
            return render_template('task_form.html', task=None, categories=Category.query.all())

        due_date = datetime.strptime(due_date_str, '%Y-%m-%d').date() if due_date_str else None
        task = Task(title=title, description=description, priority=priority, status=status,
                    due_date=due_date, user_id=current_user.id,
                    category_id=int(category_id) if category_id else None)
        db.session.add(task)
        db.session.commit()
        flash('Task created', 'success')
        return redirect(url_for('tasks.list_tasks'))
    return render_template('task_form.html', task=None, categories=Category.query.all())

@tasks_bp.route('/<int:task_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_task(task_id):
    task = Task.query.filter_by(id=task_id, user_id=current_user.id).first_or_404()
    if request.method == 'POST':
        task.title = request.form.get('title', '').strip()
        task.description = request.form.get('description', '').strip()
        task.priority = request.form.get('priority', 'Medium')
        task.status = request.form.get('status', 'Pending')
        due_date_str = request.form.get('due_date', '').strip()
        task.due_date = datetime.strptime(due_date_str, '%Y-%m-%d').date() if due_date_str else None
        category_id = request.form.get('category_id') or None
        task.category_id = int(category_id) if category_id else None

        if not task.title:
            flash('Title is required', 'danger')
            return render_template('task_form.html', task=task, categories=Category.query.all())

        db.session.commit()
        flash('Task updated', 'success')
        return redirect(url_for('tasks.list_tasks'))
    return render_template('task_form.html', task=task, categories=Category.query.all())

@tasks_bp.route('/<int:task_id>/delete', methods=['POST'])
@login_required
def delete_task(task_id):
    task = Task.query.filter_by(id=task_id, user_id=current_user.id).first_or_404()
    db.session.delete(task)
    db.session.commit()
    flash('Task deleted', 'info')
    return redirect(url_for('tasks.list_tasks'))

@tasks_bp.route('/categories/create', methods=['POST'])
@login_required
def create_category():
    name = request.form.get('name', '').strip()
    if name:
        if not Category.query.filter_by(name=name).first():
            db.session.add(Category(name=name))
            db.session.commit()
            flash('Category added', 'success')
        else:
            flash('Category already exists', 'warning')
    else:
        flash('Category name cannot be empty', 'danger')
    return redirect(url_for('tasks.list_tasks'))
