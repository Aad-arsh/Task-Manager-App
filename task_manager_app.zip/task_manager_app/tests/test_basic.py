import json
from task_manager import create_app
from task_manager.extensions import db

def setup_app():
    app = create_app()
    app.config.update(TESTING=True)
    with app.app_context():
        db.drop_all()
        db.create_all()
    return app

def test_home():
    app = setup_app()
    client = app.test_client()
    res = client.get('/')
    assert res.status_code == 200

def test_register_login_logout():
    app = setup_app()
    client = app.test_client()

    # register
    res = client.post('/register', data={'email':'a@b.com','password':'x'} , follow_redirects=True)
    assert res.status_code == 200

    # login
    res = client.post('/login', data={'email':'a@b.com','password':'x'}, follow_redirects=True)
    assert res.status_code == 200

    # logout
    res = client.get('/logout', follow_redirects=True)
    assert res.status_code == 200
